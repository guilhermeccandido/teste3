/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'gl', {
	button: 'Modelos',
	emptyListMsg: '(Non hai modelos definidos)',
	insertOption: 'Substituír o contido actual',
	options: 'Opcións de modelos',
	selectPromptMsg: 'Seleccione o modelo a abrir no editor',
	title: 'Modelos de contido'
} );
