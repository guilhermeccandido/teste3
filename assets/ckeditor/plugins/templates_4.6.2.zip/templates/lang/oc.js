/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'oc', {
	button: 'Modèls',
	emptyListMsg: '(Cap de modèl pas disponible)',
	insertOption: 'Remplaçar lo contengut actual',
	options: 'Opcions dels modèls',
	selectPromptMsg: 'Seleccionatz lo modèl de dobrir dins l\'editor',
	title: 'Contengut dels modèls'
} );
