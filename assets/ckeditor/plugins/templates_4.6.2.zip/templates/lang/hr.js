/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'hr', {
	button: 'Predlošci',
	emptyListMsg: '(Nema definiranih predložaka)',
	insertOption: 'Zamijeni trenutne sadržaje',
	options: 'Opcije predložaka',
	selectPromptMsg: 'Molimo odaberite predložak koji želite otvoriti<br>(stvarni sadržaj će biti izgubljen):',
	title: 'Predlošci sadržaja'
} );
