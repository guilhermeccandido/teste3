/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'vi', {
	button: 'Mẫu dựng sẵn',
	emptyListMsg: '(Không có mẫu dựng sẵn nào được định nghĩa)',
	insertOption: 'Thay thế nội dung hiện tại',
	options: 'Tùy chọn mẫu dựng sẵn',
	selectPromptMsg: 'Hãy chọn mẫu dựng sẵn để mở trong trình biên tập<br>(nội dung hiện tại sẽ bị mất):',
	title: 'Nội dung Mẫu dựng sẵn'
} );
